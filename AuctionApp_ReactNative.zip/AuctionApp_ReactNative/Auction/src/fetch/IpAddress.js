const protocol = "http";
const ipAddress = "15.164.224.74";
const portNumber = "3000"

const url = protocol+"://"+ipAddress+":"+portNumber;

exports.url = url;